import React from 'react';
import styled from 'styled-components';
import PropTypes from "prop-types";

interface CardProps {
  Disable:boolean;
  width:number,
  height:number,
  background:string,
}

const CardLabel = styled.div<{ Disable: boolean; width: number; height: number, background: string }>`
  cursor: ${(props) => (props.Disable ? 'not-allowed' : 'pointer')};
  width: fit-content;
  height: fit-content;
  filter: ${(props) => (props.Disable ? 'grayscale(100%)' : 'none')}; 
  background-color: ${(props) => props.background};
  border-radius: 20px;
  overflow: hidden;
  cursor: ${(props) => (props.Disable ? 'not-allowed' : 'pointer')};
  img{
    width: 12rem;
  }
  h1{
    margin: 5px 20px;
  }
  caption{
    margin: 5px 20px 0px;
  }
  p{
    margin: 0px 20px;
  }
`;

const Label: React.FC<CardProps> = ({ Disable, width, height, background }) => { // Fixed: Added backgroundColor prop
  return (
    <CardLabel Disable = { Disable } width = { width } height={ height } background= {background}>
        <img src="https://i.pinimg.com/originals/a4/14/65/a4146557789badcd399adfeb7e6e9dce.jpg" alt="" />
        <h1>Bro</h1>
        <caption>$9</caption>
        <p>a good bro!!</p>
    </CardLabel>
  );
};

export default Label;
