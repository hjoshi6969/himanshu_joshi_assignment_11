import React from "react";
import Hero from "./Hero";

export default {
  title: "Hero",
  component: Hero,
  argTypes: {
    Disable: { control: 'boolean' },
  },
}  

const Template = (args) => <Hero {...args} />;

export const Normal = Template.bind({});
Normal.args = {
  link: "https://th.bing.com/th/id/R.b0bded0a7cf2035124c2b8355025f13e?rik=e%2bRBHt4LS8Th7g&riu=http%3a%2f%2fscreenfish.net%2fwp-content%2fuploads%2f2015%2f10%2fsuper-collage.jpg&ehk=nNClp9oH9vH%2bgkLxNnCJ3BJOEZ9Hpm%2bkgimkG5nOcMc%3d&risl=&pid=ImgRaw&r=0",
  Disable: false,
};

export const Disable = Template.bind({});
Disable.args = {
  link: "https://th.bing.com/th/id/R.b0bded0a7cf2035124c2b8355025f13e?rik=e%2bRBHt4LS8Th7g&riu=http%3a%2f%2fscreenfish.net%2fwp-content%2fuploads%2f2015%2f10%2fsuper-collage.jpg&ehk=nNClp9oH9vH%2bgkLxNnCJ3BJOEZ9Hpm%2bkgimkG5nOcMc%3d&risl=&pid=ImgRaw&r=0",
  Disable: true, 
};
