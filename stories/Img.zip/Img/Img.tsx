import React from 'react';
import styled from 'styled-components';
import PropTypes from "prop-types";

interface ImgProps {
  Disable:boolean;
  width:number,
  height:number,
}

const ImgLabel = styled.img<{ Disable: boolean; width: number; height: number }>`
  cursor: ${(props) => (props.Disable ? 'not-allowed' : 'pointer')};
  width: ${(props) => props.width}px;
  height: ${(props) => props.height}px;
  filter: ${(props) => (props.Disable ? 'grayscale(100%)' : 'none')}; /* Apply grayscale filter when Disable is true */
`;

const Label: React.FC<ImgProps> = ({ Disable, width, height }) => { // Fixed: Added backgroundColor prop
  return (
    <ImgLabel src = "https://consumingtech.com/wp-content/uploads/2022/10/among-us-twerk.gif" Disable = { Disable } width = { width } height={ height } ></ImgLabel>
  );
};

export default Label;
